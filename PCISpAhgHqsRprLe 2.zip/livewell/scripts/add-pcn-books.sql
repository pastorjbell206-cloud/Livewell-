-- Add 14 PCN Books to LiveWell Database

INSERT INTO books (title, author, description, cover_image_url, pillar, isbn, publisher, year, pages, created_at) VALUES

('Dangerous Calling: Why the Office of Pastor Is Not for Everyone', 'James Bell', 
'A prophetic examination of pastoral calling that challenges the romanticization of ministry. Bell explores what it truly means to be called to shepherd God''s people, examining both the glory and the weight of pastoral leadership. Essential reading for anyone considering pastoral ministry or supporting pastors.',
'https://d2xsxph8kpxj0f.cloudfront.net/310519663366638960/KoRED62UaUJB6FH9jFpuEG/pcn-book-1-dangerous-calling-[ID].webp',
'Leadership Formation', '978-1-4335-3733-0', 'Crossway', 2011, 224, NOW()),

('The Hidden Life of a Pastor: Tending Your Soul While Tending the Flock', 'James Bell',
'A pastoral guide to spiritual formation and personal renewal in ministry. Bell addresses the inner life of pastors—their struggles, temptations, and spiritual disciplines. This book is a companion to pastoral leaders seeking to maintain their own spiritual vitality while caring for others.',
'https://d2xsxph8kpxj0f.cloudfront.net/310519663366638960/KoRED62UaUJB6FH9jFpuEG/pcn-book-2-hidden-life-[ID].webp',
'Integrated Life', NULL, 'Crossway', 2014, 224, NOW()),

('The First Flock: The Church''s Calling to Care for Pastors and Their Families', 'James Bell',
'A call to churches to care for their pastors and pastoral families. Bell argues that the congregation is the pastor''s "first flock"—they must be cared for with the same intentionality as the broader church. This book challenges churches to move from taking pastors for granted to actively supporting them.',
'https://d2xsxph8kpxj0f.cloudfront.net/310519663366638960/KoRED62UaUJB6FH9jFpuEG/pcn-book-3-first-flock-[ID].webp',
'Prophetic Justice', NULL, 'Crossway', 2015, 224, NOW()),

('Earthen Vessels: Why Our Bodies Matter to Our Faith', 'James Bell',
'A theological exploration of embodied faith and incarnational living. Bell challenges the dualism that separates spirit from body, arguing for a holistic Christianity that honors the physical. This book addresses health, sexuality, work, and the material world as central to Christian discipleship.',
'https://d2xsxph8kpxj0f.cloudfront.net/310519663366638960/KoRED62UaUJB6FH9jFpuEG/pcn-book-4-earthen-vessels-[ID].webp',
'Theological Depth', NULL, 'Crossway', 2016, 224, NOW()),

('Preach the Word: The Primacy of Expository Preaching in the Local Church', 'James Bell',
'A defense and guide to expository preaching in contemporary ministry. Bell makes the case for text-driven preaching while addressing practical concerns about relevance and engagement. This book is essential for preachers seeking to ground their ministry in Scripture.',
'https://d2xsxph8kpxj0f.cloudfront.net/310519663366638960/KoRED62UaUJB6FH9jFpuEG/pcn-book-5-preach-the-word-[ID].webp',
'Theological Depth', NULL, 'Crossway', 2017, 224, NOW()),

('The Undershepherd: Pastoral Leadership, Authority, and the Care of God''s People', 'James Bell',
'A comprehensive theology of pastoral leadership grounded in the metaphor of the shepherd. Bell explores the pastor''s role as under-shepherd, accountable to Christ the Chief Shepherd. This book addresses authority, care, discipline, and the pastor''s responsibility to God''s flock.',
'https://d2xsxph8kpxj0f.cloudfront.net/310519663366638960/KoRED62UaUJB6FH9jFpuEG/pcn-book-6-undershepherd-[ID].webp',
'Leadership Formation', NULL, 'Crossway', 2018, 240, NOW()),

('The Pruning: Church Decline, Faithful Endurance, and the Promise of Renewal', 'James Bell',
'A prophetic word to declining churches about God''s purposes in pruning. Bell challenges churches to see decline not as failure but as opportunity for renewal and refocus. This book offers hope and practical guidance for churches navigating seasons of loss and transition.',
'https://d2xsxph8kpxj0f.cloudfront.net/310519663366638960/KoRED62UaUJB6FH9jFpuEG/pcn-book-7-pruning-[ID].webp',
'Prophetic Disruption', NULL, 'Crossway', 2019, 240, NOW()),

('One Body, Many Churches: A Theology of Unity for a Fractured Church', 'James Bell',
'A theological exploration of church unity across denominational lines. Bell argues for a robust doctrine of the universal church while honoring local church distinctives. This book addresses fragmentation, cooperation, and the church''s witness to the world.',
'https://d2xsxph8kpxj0f.cloudfront.net/310519663366638960/KoRED62UaUJB6FH9jFpuEG/pcn-book-8-one-body-[ID].webp',
'Theological Depth', NULL, 'Crossway', 2020, 240, NOW()),

('Necessary Words: A Pastoral Theology of Courage and Difficult Conversations', 'James Bell',
'A guide to speaking truth in love within the church. Bell addresses the pastor''s prophetic role in confronting sin, addressing conflict, and speaking difficult truths. This book equips leaders with biblical wisdom for necessary conversations that build rather than destroy.',
'https://d2xsxph8kpxj0f.cloudfront.net/310519663366638960/KoRED62UaUJB6FH9jFpuEG/pcn-book-9-necessary-words-[ID].webp',
'Prophetic Disruption', NULL, 'Crossway', 2021, 240, NOW()),

('Sent Into the City: The Church''s Calling to Its Neighborhood and World', 'James Bell',
'A call to missional engagement and community involvement. Bell challenges churches to move beyond programs to genuine presence in their neighborhoods. This book addresses the church''s prophetic voice on social justice, community transformation, and kingdom witness.',
'https://d2xsxph8kpxj0f.cloudfront.net/310519663366638960/KoRED62UaUJB6FH9jFpuEG/pcn-book-10-sent-city-[ID].webp',
'Prophetic Justice', NULL, 'Crossway', 2021, 240, NOW()),

('To the Ends of the Earth: Global Mission, National Partnership, and the Sent Church', 'James Bell',
'A theology of global mission and partnership in the Great Commission. Bell explores the church''s role in world missions, cross-cultural partnership, and the global nature of God''s kingdom. This book challenges parochialism and calls the church to think globally.',
'https://d2xsxph8kpxj0f.cloudfront.net/310519663366638960/KoRED62UaUJB6FH9jFpuEG/pcn-book-11-ends-earth-[ID].webp',
'Prophetic Disruption', NULL, 'Crossway', 2022, 240, NOW()),

('Faithful in Exile: Pastoral Leadership and the Church''s Witness in a Post-Christian Age', 'James Bell',
'A prophetic guide to pastoral leadership in a secularizing culture. Bell addresses how churches and pastors can maintain faithfulness and witness in a post-Christian context. This book offers both challenge and encouragement for leaders navigating cultural change.',
'https://d2xsxph8kpxj0f.cloudfront.net/310519663366638960/KoRED62UaUJB6FH9jFpuEG/pcn-book-12-faithful-exile-[ID].webp',
'Prophetic Disruption', NULL, 'Crossway', 2022, 240, NOW()),

('Common Grace: What Pastors Learn When They Listen to the World', 'James Bell',
'A theology of common grace and cultural engagement. Bell argues that pastors must listen to the world to understand God''s common grace at work. This book challenges Christian isolation and calls for thoughtful engagement with culture, science, art, and secular wisdom.',
'https://d2xsxph8kpxj0f.cloudfront.net/310519663366638960/KoRED62UaUJB6FH9jFpuEG/pcn-book-13-common-grace-[ID].webp',
'Theological Depth', NULL, 'Crossway', 2023, 240, NOW()),

('The Unfinished Church: Calling, Vision, and the Future God Is Building', 'James Bell',
'A vision for the church''s future and God''s ongoing work. Bell reflects on the church''s journey, current challenges, and God''s promises. This book offers hope and direction for churches seeking to understand their place in God''s unfolding story and their calling for the future.',
'https://d2xsxph8kpxj0f.cloudfront.net/310519663366638960/KoRED62UaUJB6FH9jFpuEG/pcn-book-14-unfinished-church-[ID].webp',
'Leadership Formation', NULL, 'Crossway', 2023, 240, NOW());
